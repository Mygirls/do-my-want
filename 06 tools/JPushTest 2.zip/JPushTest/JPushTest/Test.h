//
//  Test.h
//  JPushTest
//
//  Created by cfzq on 2017/7/20.
//  Copyright © 2017年 cfzq. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Test : NSObject

@end
