//
//  Use this file to import your target's public headers that you would like to expose to Swift.
//

// JPush
#import "JPUSHService.h"
#ifdef NSFoundationVersionNumber_iOS_9_x_Max    // iOS10注册APNs所需头文件
#import <UserNotifications/UserNotifications.h>
#endif
// 如果需要使用idfa功能所需要引入的头文件（可选）
#import <AdSupport/AdSupport.h>


