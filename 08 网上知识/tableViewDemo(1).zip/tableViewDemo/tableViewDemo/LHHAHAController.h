//
//  LHHAHAController.h
//  tableViewDemo
//
//  Created by liuhao on 17/3/28.
//  Copyright © 2017年 liuhao. All rights reserved.
//

#import "LHBaseController.h"

@interface LHHAHAController : LHBaseController

@end
