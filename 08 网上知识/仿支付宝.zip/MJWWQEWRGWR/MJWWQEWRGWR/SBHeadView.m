//
//  SBHeadView.m
//  MJWWQEWRGWR
//
//  Created by 曹健 on 17/3/6.
//  Copyright © 2017年 曹健. All rights reserved.
//

#import "SBHeadView.h"

@implementation SBHeadView
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/
/*
- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
    UIView *view = [super hitTest:point withEvent:event];
NSLog(@"%@ --",view.class);
    if (view == self) {
        return nil;
    }
    
    return view;
}
 */

@end
