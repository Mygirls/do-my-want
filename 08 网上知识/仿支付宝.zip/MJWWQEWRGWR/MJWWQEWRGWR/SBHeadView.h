//
//  SBHeadView.h
//  MJWWQEWRGWR
//
//  Created by 曹健 on 17/3/6.
//  Copyright © 2017年 曹健. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SBHeadView : UIView

@end
