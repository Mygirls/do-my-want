//
//  ViewController.h
//  YSCAnimationDemo
//
//  Created by yushichao on 16/8/22.
//  Copyright © 2016年 YSC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UINavigationController


@end

