//
//  YSCButterflyViewController.h
//  YSCAnimationDemo
//
//  Created by yushichao on 16/8/25.
//  Copyright © 2016年 YSC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YSCButterflyViewController : UIViewController

@end
