//
//  YSCFanshapedViewController.h
//  YSCAnimationDemo
//
//  Created by yushichao on 16/8/24.
//  Copyright © 2016年 YSC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YSCFanshapedViewController : UIViewController

@end
