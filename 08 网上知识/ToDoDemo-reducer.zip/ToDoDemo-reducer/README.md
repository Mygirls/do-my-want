# View Controller with Unidirection Data Flow

This is a repo for my blog post [here](https://onevcat.com/2017/07/state-based-viewcontroller/).

See [basic](https://github.com/onevcat/ToDoDemo/tree/basic), [state](https://github.com/onevcat/ToDoDemo/tree/state) and [reducer](https://github.com/onevcat/ToDoDemo/tree/reducer) branches for detail.